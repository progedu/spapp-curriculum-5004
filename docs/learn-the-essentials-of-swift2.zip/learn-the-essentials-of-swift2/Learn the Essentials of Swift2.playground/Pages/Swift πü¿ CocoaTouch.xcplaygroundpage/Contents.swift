// Copyright© DWANGO Co.,Ltd. All Rights Reserved.
/*:
 # Swift と CocoaTouch
 ## Swift Standard Library

 今まで紹介したデータ型は Swift Standard Library に含まれています。
 */



/*:
 > `String` や `Array` を Option+Click して Swift Standard Library の型を読んでみましょう。
 */

/*:
 ## UIKit
 */



//: [Previous](@previous)
